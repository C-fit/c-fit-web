"use client"

import { useState, useEffect } from "react"
import { Search, Grid3X3, List } from "lucide-react"
import { Navigation } from "@/components/navigation"
import { JobCard } from "@/components/job-card"
import { JobFilters } from "@/components/job-filters"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import type { JobPosting, JobSearchFilters } from "@/lib/types"

// Mock data - in real app this would come from API
const mockJobs: JobPosting[] = [
  {
    id: "1",
    title: "프론트엔드 개발자",
    companyName: "네이버",
    description:
      "React, TypeScript를 활용한 웹 서비스 개발을 담당하실 프론트엔드 개발자를 모집합니다. 사용자 경험을 중시하며 최신 기술 트렌드에 관심이 많은 분을 찾고 있습니다.",
    requirements: "React, TypeScript 경험 3년 이상, 웹 표준 및 접근성에 대한 이해",
    preferred: "Next.js, GraphQL 경험자 우대, 디자인 시스템 구축 경험",
    location: "서울 강남구",
    salary: "연봉 4,000~6,000만원",
    jobType: "full-time",
    techStack: ["React", "TypeScript", "Next.js", "GraphQL"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-15"),
  },
  {
    id: "2",
    title: "백엔드 개발자",
    companyName: "카카오",
    description:
      "Spring Boot를 활용한 대규모 서비스 백엔드 개발을 담당하실 개발자를 찾습니다. 높은 트래픽을 처리하는 안정적인 시스템 구축 경험이 있으신 분을 모집합니다.",
    requirements: "Java, Spring 경험 5년 이상, 대용량 데이터 처리 경험",
    preferred: "MSA, Kubernetes 경험자 우대, AWS/GCP 클라우드 경험",
    location: "경기 성남시",
    salary: "연봉 5,000~7,000만원",
    jobType: "full-time",
    techStack: ["Java", "Spring Boot", "MySQL", "Redis", "Kubernetes"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-14"),
    updatedAt: new Date("2024-01-14"),
  },
  {
    id: "3",
    title: "AI 엔지니어",
    companyName: "삼성전자",
    description:
      "머신러닝 모델 개발 및 AI 서비스 구축을 담당하실 AI 엔지니어를 모집합니다. 최신 AI 기술을 활용한 혁신적인 제품 개발에 참여하실 분을 찾습니다.",
    requirements: "Python, TensorFlow/PyTorch 경험, 머신러닝 모델 개발 경험",
    preferred: "MLOps, 클라우드 경험자 우대, 논문 게재 경험",
    location: "서울 서초구",
    salary: "연봉 6,000~8,000만원",
    jobType: "full-time",
    techStack: ["Python", "TensorFlow", "PyTorch", "AWS", "Docker"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-13"),
    updatedAt: new Date("2024-01-13"),
  },
  {
    id: "4",
    title: "DevOps 엔지니어",
    companyName: "쿠팡",
    description: "클라우드 인프라 구축 및 운영, CI/CD 파이프라인 관리를 담당하실 DevOps 엔지니어를 모집합니다.",
    requirements: "AWS/GCP 경험 3년 이상, Docker/Kubernetes 운영 경험",
    preferred: "Terraform, Ansible 경험자 우대",
    location: "서울 송파구",
    salary: "연봉 5,500~7,500만원",
    jobType: "full-time",
    techStack: ["AWS", "Kubernetes", "Docker", "Terraform", "Jenkins"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-12"),
    updatedAt: new Date("2024-01-12"),
  },
  {
    id: "5",
    title: "풀스택 개발자",
    companyName: "토스",
    description:
      "프론트엔드부터 백엔드까지 전체 스택을 다루는 풀스택 개발자를 모집합니다. 핀테크 서비스 개발 경험이 있으신 분을 우대합니다.",
    requirements: "React, Node.js 경험 3년 이상, 데이터베이스 설계 경험",
    preferred: "금융 도메인 경험자 우대, TypeScript 능숙자",
    location: "서울 강남구",
    salary: "연봉 4,500~6,500만원",
    jobType: "full-time",
    techStack: ["React", "Node.js", "TypeScript", "PostgreSQL", "Redis"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-11"),
    updatedAt: new Date("2024-01-11"),
  },
  {
    id: "6",
    title: "모바일 개발자 (iOS)",
    companyName: "배달의민족",
    description:
      "iOS 네이티브 앱 개발을 담당하실 개발자를 모집합니다. 사용자 친화적인 모바일 앱 개발에 열정이 있으신 분을 찾습니다.",
    requirements: "Swift, iOS 개발 경험 3년 이상, App Store 출시 경험",
    preferred: "SwiftUI 경험자 우대, 대용량 앱 개발 경험",
    location: "서울 송파구",
    salary: "연봉 4,000~6,000만원",
    jobType: "full-time",
    techStack: ["Swift", "iOS", "SwiftUI", "Core Data"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-10"),
    updatedAt: new Date("2024-01-10"),
  },
]

export default function JobsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState<JobSearchFilters>({})
  const [sortBy, setSortBy] = useState("latest")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [currentPage, setCurrentPage] = useState(1)
  const [filteredJobs, setFilteredJobs] = useState(mockJobs)

  const jobsPerPage = 9
  const totalPages = Math.ceil(filteredJobs.length / jobsPerPage)
  const startIndex = (currentPage - 1) * jobsPerPage
  const currentJobs = filteredJobs.slice(startIndex, startIndex + jobsPerPage)

  // Filter jobs based on search and filters
  useEffect(() => {
    let filtered = mockJobs

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (job) =>
          job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.techStack.some((tech) => tech.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    }

    // Job type filter
    if (filters.jobType) {
      filtered = filtered.filter((job) => job.jobType === filters.jobType)
    }

    // Location filter
    if (filters.location) {
      filtered = filtered.filter((job) => job.location?.includes(filters.location!))
    }

    // Tech stack filter
    if (filters.techStack && filters.techStack.length > 0) {
      filtered = filtered.filter((job) => filters.techStack!.some((tech) => job.techStack.includes(tech)))
    }

    // Sort jobs
    if (sortBy === "latest") {
      filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    } else if (sortBy === "company") {
      filtered.sort((a, b) => a.companyName.localeCompare(b.companyName))
    }

    setFilteredJobs(filtered)
    setCurrentPage(1) // Reset to first page when filters change
  }, [searchQuery, filters, sortBy])

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">채용공고</h1>
          <p className="text-muted-foreground">
            총 <span className="font-semibold text-foreground">{filteredJobs.length}</span>개의 채용공고가 있습니다
          </p>
        </div>

        {/* Search and Filters */}
        <div className="space-y-4 mb-8">
          {/* Search Bar */}
          <div className="relative max-w-2xl">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="기업명, 직무, 기술 스택으로 검색..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 text-base"
            />
          </div>

          {/* Filters and Controls */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <JobFilters filters={filters} onFiltersChange={setFilters} />

            <div className="flex items-center gap-2">
              {/* Sort */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="latest">최신순</SelectItem>
                  <SelectItem value="company">회사명순</SelectItem>
                </SelectContent>
              </Select>

              {/* View Mode */}
              <div className="flex border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  className="rounded-r-none"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Job Listings */}
        {filteredJobs.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg mb-4">검색 조건에 맞는 채용공고가 없습니다</p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("")
                setFilters({})
              }}
            >
              필터 초기화
            </Button>
          </div>
        ) : (
          <>
            <div className={viewMode === "grid" ? "grid gap-6 md:grid-cols-2 lg:grid-cols-3" : "space-y-4"}>
              {currentJobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-12 flex justify-center">
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious
                        href="#"
                        onClick={(e) => {
                          e.preventDefault()
                          if (currentPage > 1) setCurrentPage(currentPage - 1)
                        }}
                        className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                      />
                    </PaginationItem>

                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                      <PaginationItem key={page}>
                        <PaginationLink
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setCurrentPage(page)
                          }}
                          isActive={currentPage === page}
                        >
                          {page}
                        </PaginationLink>
                      </PaginationItem>
                    ))}

                    <PaginationItem>
                      <PaginationNext
                        href="#"
                        onClick={(e) => {
                          e.preventDefault()
                          if (currentPage < totalPages) setCurrentPage(currentPage + 1)
                        }}
                        className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  )
}
