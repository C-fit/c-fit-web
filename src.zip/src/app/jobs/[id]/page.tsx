"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { MapPin, Clock, Briefcase, Heart, ExternalLink, Sparkles, Building2 } from "lucide-react"
import { Navigation } from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { SimilarJobs } from "@/components/similar-jobs"
import type { JobPosting } from "@/lib/types"

// Mock data - in real app this would come from API
const mockJob: JobPosting = {
  id: "1",
  title: "프론트엔드 개발자",
  companyName: "네이버",
  description: `React, TypeScript를 활용한 웹 서비스 개발을 담당하실 프론트엔드 개발자를 모집합니다.

네이버의 다양한 서비스에서 사용자 경험을 개선하고, 최신 기술을 도입하여 더 나은 웹 서비스를 만들어가실 분을 찾고 있습니다.

주요 업무:
• React, TypeScript를 활용한 웹 애플리케이션 개발
• 사용자 인터페이스 및 사용자 경험 개선
• 크로스 브라우저 호환성 및 웹 접근성 준수
• 백엔드 개발팀과의 API 연동 및 협업
• 코드 리뷰 및 기술 문서 작성`,
  requirements: `• React, TypeScript 경험 3년 이상
• HTML, CSS, JavaScript에 대한 깊은 이해
• 웹 표준 및 접근성에 대한 이해
• Git을 활용한 협업 경험
• RESTful API 연동 경험`,
  preferred: `• Next.js, GraphQL 경험자 우대
• 디자인 시스템 구축 경험
• 테스트 코드 작성 경험 (Jest, Testing Library)
• 웹 성능 최적화 경험
• 오픈소스 기여 경험`,
  location: "서울 강남구",
  salary: "연봉 4,000~6,000만원",
  jobType: "full-time",
  techStack: ["React", "TypeScript", "Next.js", "GraphQL", "Jest"],
  sourceUrl: "https://example.com",
  createdAt: new Date("2024-01-15"),
  updatedAt: new Date("2024-01-15"),
}

// Mock related jobs
const relatedJobs: JobPosting[] = [
  {
    id: "2",
    title: "React 개발자",
    companyName: "카카오",
    description: "React를 활용한 웹 서비스 개발",
    requirements: "React 경험 2년 이상",
    location: "경기 성남시",
    salary: "연봉 3,500~5,500만원",
    jobType: "full-time",
    techStack: ["React", "JavaScript", "Redux"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-14"),
    updatedAt: new Date("2024-01-14"),
  },
  {
    id: "3",
    title: "프론트엔드 엔지니어",
    companyName: "라인",
    description: "TypeScript와 React를 활용한 대규모 서비스 개발",
    requirements: "TypeScript, React 경험 3년 이상",
    location: "서울 강남구",
    salary: "연봉 4,500~6,500만원",
    jobType: "full-time",
    techStack: ["TypeScript", "React", "Next.js", "GraphQL"],
    sourceUrl: "https://example.com",
    createdAt: new Date("2024-01-13"),
    updatedAt: new Date("2024-01-13"),
  },
]

export default function JobDetailPage() {
  const params = useParams()
  const [isSaved, setIsSaved] = useState(false)

  // In real app, fetch job data based on params.id
  const job = mockJob

  if (!job) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">채용공고를 찾을 수 없습니다</h1>
            <Button asChild>
              <a href="/jobs">채용공고 목록으로 돌아가기</a>
            </Button>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Job Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <h1 className="text-3xl font-bold text-balance">{job.title}</h1>
                    <div className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-muted-foreground" />
                      <span className="text-xl font-semibold text-muted-foreground">{job.companyName}</span>
                    </div>
                  </div>
                  <Button
                    variant={isSaved ? "default" : "outline"}
                    onClick={() => setIsSaved(!isSaved)}
                    className="shrink-0"
                  >
                    <Heart className={`h-4 w-4 mr-2 ${isSaved ? "fill-current" : ""}`} />
                    {isSaved ? "저장됨" : "관심공고"}
                  </Button>
                </div>

                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  {job.location && (
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{job.location}</span>
                    </div>
                  )}
                  {job.jobType && (
                    <div className="flex items-center gap-1">
                      <Briefcase className="h-4 w-4" />
                      <span>{job.jobType === "full-time" ? "정규직" : job.jobType}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(job.createdAt).toLocaleDateString("ko-KR")}</span>
                  </div>
                </div>

                {job.salary && <div className="text-lg font-semibold text-primary">{job.salary}</div>}
              </CardHeader>
            </Card>

            {/* AI Match Alert */}
            <Alert className="border-primary/20 bg-primary/5">
              <Sparkles className="h-4 w-4 text-primary" />
              <AlertDescription className="text-primary">
                <strong>AI 매칭도 85%</strong> - 당신의 프로필과 매우 잘 맞는 공고입니다!
              </AlertDescription>
            </Alert>

            {/* Job Description */}
            <Card>
              <CardHeader>
                <CardTitle>채용 상세</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  <div className="whitespace-pre-line text-sm leading-relaxed">{job.description}</div>
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card>
              <CardHeader>
                <CardTitle>자격 요건</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="whitespace-pre-line text-sm leading-relaxed">{job.requirements}</div>
              </CardContent>
            </Card>

            {/* Preferred Qualifications */}
            {job.preferred && (
              <Card>
                <CardHeader>
                  <CardTitle>우대 사항</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="whitespace-pre-line text-sm leading-relaxed">{job.preferred}</div>
                </CardContent>
              </Card>
            )}

            {/* Tech Stack */}
            <Card>
              <CardHeader>
                <CardTitle>기술 스택</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {job.techStack.map((tech) => (
                    <Badge key={tech} variant="secondary" className="text-sm py-1 px-3">
                      {tech}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Apply Button */}
            <Card>
              <CardContent className="p-6">
                <Button size="lg" className="w-full mb-4">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  지원하러 가기
                </Button>
                <p className="text-xs text-muted-foreground text-center">원본 채용 사이트로 이동합니다</p>
              </CardContent>
            </Card>

            {/* Company Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">기업 정보</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Building2 className="h-8 w-8 text-muted-foreground" />
                  <div>
                    <div className="font-semibold">{job.companyName}</div>
                    <div className="text-sm text-muted-foreground">IT 서비스</div>
                  </div>
                </div>
                <Separator />
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">업계</span>
                    <span>인터넷/IT</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">규모</span>
                    <span>대기업</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">설립</span>
                    <span>1999년</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Related Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  유사한 채용공고
                </CardTitle>
              </CardHeader>
              <CardContent>
                <SimilarJobs jobId={params.id as string} />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
