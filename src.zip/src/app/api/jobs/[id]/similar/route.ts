import { type Request, NextResponse } from 'next/server'; // NextRequest를 Request로 변경
import { findSimilarJobs } from '@/lib/ai-recommendations';

// Mock job data (same as above)
const mockJobs = [
  {
    id: '1',
    title: '시니어 프론트엔드 개발자',
    company: '네이버',
    location: '서울 강남구',
    salary: 80000000,
    jobType: '정규직',
    description: 'React, TypeScript를 활용한 웹 서비스 개발',
    requirements: 'React, TypeScript, JavaScript, HTML, CSS',
    postedAt: new Date(),
    deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
  },
  // ... (다른 mockJobs 데이터는 동일하게 유지)
  {
    id: '4',
    title: '프론트엔드 개발자',
    company: 'LG전자',
    location: '서울 강남구',
    salary: 70000000,
    jobType: '정규직',
    description: 'Vue.js, React를 활용한 웹 개발',
    requirements: 'Vue.js, React, JavaScript, CSS',
    postedAt: new Date(),
    deadline: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
  },
];

// request를 사용하지 않으므로 _request로 변경 (권장사항)
export async function GET(
  _request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const jobId = params.id;
    const targetJob = mockJobs.find((job) => job.id === jobId);

    if (!targetJob) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    const similarJobs = findSimilarJobs(targetJob, mockJobs, 3);

    return NextResponse.json({ similarJobs });
  } catch (error) {
    console.error('Similar jobs error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
